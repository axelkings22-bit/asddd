package com.deadbodies;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;

public class DeadBodiesClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		ClientTickEvents.END_CLIENT_TICK.register(CorpseManager::tick);
		ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> CorpseManager.clear());
	}
}
